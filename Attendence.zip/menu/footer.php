<div id="footer">
    <p>
        &copy; 2012 <strong>Global Web Solution</strong> |
        <a href="#" title="Website Templates">website templates</a> by <a href="https://www.globalwebsolution.biz">styleshout</a> |
        Valid <a href="#">XHTML</a> | 
        <a href="#">CSS</a>   		
    </p>
</div>
<?php $_SESSION['Msg']=''; ?>