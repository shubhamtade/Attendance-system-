<div id="header">
    <h1 id="logo-text"><a href=".">Your Group Name</a></h1>
    <p id="slogan">Software Solution</p>
    <div id="header-links">
        <p>
            <a href=".">Home</a> | 
            <a href="AddAttendance.php">Add Attendance</a> | 
            <a href="EmployeeRegister.php">Employee Register</a>
        </p>
    </div>
</div>