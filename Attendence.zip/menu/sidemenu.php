<div id="sidebar">
    <h2>Sidebar Menu</h2>
    <ul class="sidemenu">				
        <li><a href=".">Home</a></li>
        <li><a href="#">Template Info</a></li>
        <li><a href="#">Sample Tags</a></li>
    </ul>	
</div>